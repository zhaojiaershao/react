import React, { Component } from 'react';
//引入样式文件
import '../style/index.scss';

export default class But extends Component {
  render() {
    return (
      <div className="btn-zrb">
        <div className="zhang">
          <button>张良</button>
        </div>
        <div className="zhou">
          <button>周瑜</button>
        </div>
        <div className="cao">
          <button>曹操</button>
        </div>
      </div>
    );
  }
}
