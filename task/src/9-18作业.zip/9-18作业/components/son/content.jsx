import React, { Component } from 'react';
//引入样式文件
import '../style/index.scss';

//引入左边按钮
import But from '../son/but';

//引入上下文对象
import Mycontext from '../context/index';

export default class content extends Component {
  render() {
    return (
      <div className="context-zrb">
        <But />
        <div className="content-zrb-2"></div>
      </div>
    );
  }
}
