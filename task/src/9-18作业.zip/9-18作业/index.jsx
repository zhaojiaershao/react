import React, { Component } from 'react';
//引入头部导航按钮
import Topnav from './components/son/Topnav';
//引入内容
import Content from './components/son/content';

//引入上下文对象
import MyContext from './components/context';

//样式
import './components/style/index.scss';

export default class Index extends Component {
  render() {
    return (
      <div className="max-zrb">
        <Topnav />
        <Content />
      </div>
    );
  }
}
